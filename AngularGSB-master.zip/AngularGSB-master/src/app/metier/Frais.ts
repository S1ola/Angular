export class Frais
{
  public id_frais: number=0;
  public anneemois: string="";
  public datemodification: Date = new Date('0000-00-00');
  public montantvalide: number =0;
  public nbjustificatifs: number=0;
  public id_visiteur:  number=0;
  public id_etat : number=0;
  public lib_etat : string="";
}

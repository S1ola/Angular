export class Etat {
  public id_etat:number = 0;
  public lib_etat: string ='';
}
